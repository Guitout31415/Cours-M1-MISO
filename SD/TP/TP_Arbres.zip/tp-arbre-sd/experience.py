from binary_search_tree import *
import sys
import graphviz
from gene import *
from extendedlist import *
import timeit
from random import randint
from random import shuffle

def compare_gene_lengths(a,b):
    """Compare les gènes a et b en fonction de leurs longueurs.

    :param a: (Gene) 1er gene
    :param b: (Gene) 2nd gene
    :return: (int)
        -1 si a < b,
        0 si a = b,
        1 sinon
    """
    if len(a) < len(b):
        return -1
    elif len(a) == len(b):
        return 0
    else:
        return 1

def load_gff(filepath, gene_list, is_extended_list):
    gff = open(filepath)
    for line in gff.readlines():
        fields = line.split('\t')
        if len(fields) > 3 and fields[2] == "gene":
            g = Gene.from_gff(line)
            if g:
                if is_extended_list:
                    # Notez qu'on ne peut pas faire de append pour les ExtendedList
                    # mais ce n'est pas grave, à la place on ajoute en tête.
                    gene_list = ExtendedList(g, gene_list)
                else:
                    gene_list.append(g)
    return gene_list

#Main program
if __name__ == '__main__':
    fil = sys.argv[1]

    gene_list_extended = load_gff(fil, ExtendedList(), True)
    gene_list_not_extended = load_gff(fil, [], False)

    t = BinarySearchTree()
    shuffle(gene_list_not_extended)
    for gene in gene_list_not_extended:
        try:
            t.insert(gene, compare_gene_lengths)
        except:
            pass

    graphviz.Source(t.to_dot()).render(view=True)

    go_find = gene_list_not_extended[randint(0,len(gene_list_not_extended)-1)]
    time_arbre = timeit.timeit(lambda: t.search(go_find, compare_gene_lengths), number=10)/10
    time_list = timeit.timeit(lambda: gene_list_not_extended.index(go_find), number=10)/10
    time_extended = timeit.timeit(lambda: gene_list_extended.search(go_find), number=10)/10

    print("Search avec arbre :", time_arbre)
    print("Search (avec index) avec list python :", time_list)
    print("Search avec extendedlist :", time_extended)

    l = [("time_list", time_list), ("time_extended", time_extended), ("time_arbre", time_arbre)]
    l = sorted(l, key=lambda x:x[1])
    d = dict(l)
    print(f'{list(d.keys())[0]} < {list(d.keys())[1]} < {list(d.keys())[2]}')