from binary_tree import *

class BinarySearchTree(BinaryTree):

    def __init__(self, data=None, left=None, right=None):
        self._data = data
        self._left_subtree = left
        self._right_subtree = right

    def search(self, val, fun):
        """
        True si val est dans l'arbre
        """
        if fun(self._data, val) == 0:
            return True
        elif fun(self._data, val) == -1:
            if self.get_right_subtree() is None:
                return False
            else:
                return self._right_subtree.search(val, fun)
        elif fun(self._data, val) == 1:
            if self.get_left_subtree() is None:
                return False
            else:
                return self._left_subtree.search(val, fun)

    def set_left_subtree(self, elem, fun):
        """Met à jour le sous-arbre gauche de l'arbre parent.

        :param elem: élément à rajouter dans l'arbre
        :param fun: fonction de comparaison
        """
        if fun(self._data, elem) == 0:
            raise ValueError(f"{elem} est déjà dans l'arbre")
        self._left_subtree.insert(elem, fun)

    def set_right_subtree(self, elem, fun):
        """Met à jour le sous-arbre droit de l'arbre parent.

        :param elem: élément à rajouter dans l'arbre
        :param fun: fonction de comparaison
        """
        if fun(self._data, elem) == 0:
            raise ValueError(f"{elem} est déjà dans l'arbre")
        self._right_subtree.insert(elem, fun)

    def insert(self, elem, fun = lambda a,b:-1 if a<b else 0 if a==b else 1):
        """Permet d'insérer elem dans l'arbre en utilisant fun.

        :param elem: élément à rajouter dans l'arbre
        :param fun: fonction de comparaison
        """
        if self.is_empty():
            self.__init__(elem, BinarySearchTree(), BinarySearchTree())
        elif fun(elem, self._data) == -1:
            self.set_left_subtree(elem, fun)
        else:
            self.set_right_subtree(elem, fun)
