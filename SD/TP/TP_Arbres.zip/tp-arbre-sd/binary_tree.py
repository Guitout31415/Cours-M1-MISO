import time

WHITE = '#FFFFFF'
BLACK = '#000000'

def escape_str(obj):
    '''
    convertit l'objet obj en une chaîne de caractères ASCII
    fct utile pour méthode to_dot des BinaryTree
    '''
    chaine = str(obj)
    chaine_echap = ''
    for c in chaine:
        n = ord(c)
        if 32 <= n <= 126 and c != '"':
            chaine_echap += c
        else:
            chaine_echap += '\\x{:04X}'.format(n)
    return chaine_echap

class BinaryTree:

    def __init__(self, data=None, left=None, right=None):
        self._data = data
        self._left_subtree = left
        self._right_subtree = right

    def is_empty(self):
        """Vérifie si l'arbre est vide

        :return: (bool) True si vide, False sinon.
        """
        return self._data is None
        
    def get_data(self):
        """Permet d'obtenir la valeur du noeud.

        :return: valeur du noeud.
        """
        return self._data

    def get_left_subtree(self):
        """Permet d'obtenir le sous arbre gauche du noeud.

        :return: (BinaryTree) le sous-arbre gauche
        """
        return self._left_subtree

    def get_right_subtree(self):
        """Permet d'obtenir le sous arbre droit du noeud.

        :return: (BinaryTree) le sous-arbre gauche
        """
        return self._right_subtree

    def is_leaf(self):
        """Vérifie si l'arbre est une feuille.

        :return: (bool) True si le noeud est une feuille, False sinon
        """
        return (self.get_left_subtree() is None) and (self.get_right_subtree() is None)

    def inorder(self):
        """Permet de lister les éléments de l'arbre via le parcours infixe:

        :return: (list) liste des éléments de l'arbre
        """
        res = []
        if not self.is_leaf():
            r = self.get_left_subtree().inorder()
            for i in r:
                res.append(i)
            res.append(self.get_data())
        if not self.is_leaf():
            r = self.get_right_subtree().inorder()
            for i in r:
                res.append(i)
        return res

    def to_dot(self):
            '''
            :return: une chaîne de caractère contenant la représentation DOT de l'arbre
            '''
            LIEN = '\t"N({:s})" -> "N({:s})" [color="{:s}", label="{:s}", fontsize="8"];\n'

            def aux(arbre, prefix=''):
                if arbre.is_empty():
                    descr = '\t"N({:s})" [color="{:s}", label=""];\n'.format(
                        prefix,
                        WHITE)
                else:
                    c = arbre.get_data()
                    descr = '\t"N({:s})" [label="{:s}"];\n'.format(prefix,
                                                                   escape_str(
                                                                       c))
                    s_a_g = arbre.get_left_subtree()
                    label_lien, couleur_lien = (
                    'g', BLACK) if not s_a_g.is_empty() else ('', WHITE)
                    descr = (descr +
                             aux(s_a_g, prefix + 'g') +
                             LIEN.format(prefix, prefix + 'g', couleur_lien,
                                         label_lien))
                    s_a_d = arbre.get_right_subtree()
                    label_lien, couleur_lien = (
                    'd', BLACK) if not s_a_d.is_empty() else ('', WHITE)
                    descr = (descr +
                             aux(s_a_d, prefix + 'd') +
                             LIEN.format(prefix, prefix + 'd', couleur_lien,
                                         label_lien))

                return descr

            return '''/*
      Binary Tree

      Date: {}

    */

    digraph G {{
    \tbgcolor="{:s}";

    {:s}
    }}
    '''.format(time.strftime('%c'), WHITE, aux(self))
